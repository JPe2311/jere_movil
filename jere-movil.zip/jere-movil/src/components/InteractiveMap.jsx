'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { animate, motion, useMotionValue } from 'framer-motion';
import { useCollection } from '@/lib/useCollection';
import { demoPuntos } from '@/lib/demoData';
import { toMillis } from '@/lib/utils';
import { useI18n } from '@/lib/i18n';
import TimelineSlider from './TimelineSlider';
import CitySearch from './CitySearch';
import MilestoneModal from './MilestoneModal';

const DAY = 86_400_000;

/** Posición de La Bebi en el instante ts, interpolando entre dos puntos consecutivos de la ruta. */
function positionAt(puntos, ts) {
  const last = puntos[puntos.length - 1];
  if (ts <= puntos[0].ts) return { lat: puntos[0].lat, lng: puntos[0].lng, idx: 0 };
  if (ts >= last.ts) return { lat: last.lat, lng: last.lng, idx: puntos.length - 1 };
  let i = 0;
  while (i < puntos.length - 2 && puntos[i + 1].ts <= ts) i += 1;
  const a = puntos[i];
  const b = puntos[i + 1];
  const f = (ts - a.ts) / (b.ts - a.ts || 1);
  return { lat: a.lat + (b.lat - a.lat) * f, lng: a.lng + (b.lng - a.lng) * f, idx: i };
}

export default function InteractiveMap() {
  const { t } = useI18n();
  const { items, loading } = useCollection('puntos_mapa', 'fechaHora', 'asc');
  const [nowMs] = useState(() => Date.now());

  const isDemo = !loading && items.length === 0;

  // Los puntos ordenados cronológicamente definen la ruta (trazado automático).
  const puntos = useMemo(() => {
    if (loading) return [];
    const src = items.length ? items : demoPuntos;
    return src
      .map((p) => ({ ...p, ts: toMillis(p.fechaHora) }))
      .filter((p) => Number.isFinite(p.ts) && Number.isFinite(p.lat) && Number.isFinite(p.lng))
      .sort((a, b) => a.ts - b.ts);
  }, [items, loading]);

  // Rango del timeline: día 1 → hoy (o el último punto si es posterior).
  const { start, end } = useMemo(() => {
    if (!puntos.length) return { start: 0, end: 1 };
    const s = puntos[0].ts;
    const e = Math.max(nowMs, puntos[puntos.length - 1].ts);
    return { start: s, end: e === s ? s + 1 : e };
  }, [puntos, nowMs]);

  const progress = useMotionValue(1); // 0..1 sobre [start, end]
  const [current, setCurrent] = useState({ idx: 0, day: 1, ts: start });
  const [selectedId, setSelectedId] = useState(null);
  const [playing, setPlaying] = useState(false);

  const mapEl = useRef(null);
  const mapRef = useRef(null);
  const layersRef = useRef({});
  const animRef = useRef(null);

  /* ---------- 1) crear el mapa (una sola vez) ---------- */
  useEffect(() => {
    const map = L.map(mapEl.current, { zoomControl: false, worldCopyJump: true, minZoom: 2 }).setView([-5, -70], 3);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  /* ---------- helpers de animación ---------- */
  const stop = useCallback(() => {
    animRef.current?.stop();
    animRef.current = null;
    setPlaying(false);
  }, []);

  const tweenTo = useCallback(
    (p, duration = 1.2) => {
      stop();
      const target = Math.min(1, Math.max(0, (p.ts - start) / (end - start)));
      animRef.current = animate(progress, target, { duration, ease: 'easeInOut' });
    },
    [progress, start, end, stop]
  );

  const pick = useCallback(
    (id, { fly = true } = {}) => {
      const p = puntos.find((x) => x.id === id);
      if (!p) return;
      tweenTo(p);
      setSelectedId(id);
      const map = mapRef.current;
      if (fly && map) map.flyTo([p.lat, p.lng], Math.max(map.getZoom(), 6), { duration: 1.4 });
    },
    [puntos, tweenTo]
  );

  const pickRef = useRef(pick);
  useEffect(() => {
    pickRef.current = pick;
  }, [pick]);

  /* ---------- 2) capas: ruta, hitos y La Bebi ---------- */
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !puntos.length) return undefined;

    const latlngs = puntos.map((p) => [p.lat, p.lng]);
    const full = L.polyline(latlngs, {
      color: '#1F2A44', weight: 4, opacity: 0.25, dashArray: '2 10', lineCap: 'round',
    }).addTo(map);
    const done = L.polyline([], {
      color: '#FF7A3D', weight: 6, opacity: 0.95, lineCap: 'round', lineJoin: 'round',
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    puntos.forEach((p, i) => {
      const icon = L.divIcon({
        className: '',
        html: `<div class="hito-pin">${i + 1}</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      L.marker([p.lat, p.lng], { icon, title: p.ciudad || p.titulo })
        .on('click', () => pickRef.current(p.id, { fly: false }))
        .addTo(group);
    });

    const bebiIcon = L.divIcon({
      className: '',
      html: '<div class="bebi-marker"><img src="/labebi.svg" alt="La Bebi" /></div>',
      iconSize: [96, 62],
      iconAnchor: [48, 54],
    });
    const bebi = L.marker(latlngs[0], { icon: bebiIcon, zIndexOffset: 1000, interactive: false }).addTo(map);

    layersRef.current = { done, bebi };
    map.fitBounds(L.latLngBounds(latlngs).pad(0.25), { maxZoom: 6 });

    return () => {
      full.remove();
      done.remove();
      group.remove();
      bebi.remove();
      layersRef.current = {};
    };
  }, [puntos]);

  /* ---------- 3) el slider (motion value) mueve a La Bebi ---------- */
  const update = useCallback(
    (frac) => {
      const { done, bebi } = layersRef.current;
      if (!bebi || !puntos.length) return;
      const ts = start + frac * (end - start);
      const pos = positionAt(puntos, ts);
      bebi.setLatLng([pos.lat, pos.lng]);
      const path = puntos.slice(0, pos.idx + 1).map((p) => [p.lat, p.lng]);
      path.push([pos.lat, pos.lng]);
      done.setLatLngs(path);
      const day = Math.floor((ts - start) / DAY) + 1;
      setCurrent((prev) => (prev.idx === pos.idx && prev.day === day ? prev : { idx: pos.idx, day, ts }));
    },
    [puntos, start, end]
  );

  useEffect(() => {
    update(progress.get());
    return progress.on('change', update);
  }, [progress, update]);

  /* ---------- controles ---------- */
  const togglePlay = () => {
    if (playing) {
      stop();
      return;
    }
    let from = progress.get();
    if (from >= 0.999) {
      progress.set(0);
      from = 0;
    }
    setPlaying(true);
    animRef.current = animate(progress, 1, {
      duration: Math.max(4, (1 - from) * 30),
      ease: 'linear',
      onComplete: () => setPlaying(false),
    });
  };

  const scrub = (v) => {
    stop();
    progress.set(v);
  };

  useEffect(() => () => animRef.current?.stop(), []);

  const selected = puntos.find((p) => p.id === selectedId) || null;

  return (
    <div className="relative h-full w-full overflow-hidden">
      <div ref={mapEl} className="absolute inset-0 z-0" />

      {/* Buscador */}
      <div className="absolute left-3 right-3 top-3 z-[1000] sm:left-5 sm:right-auto sm:w-96">
        <CitySearch puntos={puntos} onSelect={(p) => pick(p.id)} />
      </div>

      {isDemo && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute right-3 top-16 z-[1000] rounded-full border-2 border-noche bg-rosa px-3 py-1 text-xs font-extrabold text-white shadow-comic-sm sm:top-3 sm:right-5"
        >
          🧪 {t('map_demo')}
        </motion.div>
      )}

      {loading && (
        <div className="absolute inset-0 z-[1000] grid place-items-center bg-crema/70">
          <div className="card-comic px-5 py-3 font-display text-lg font-bold">🚐 {t('loading')}</div>
        </div>
      )}

      {/* Timeline */}
      {puntos.length > 0 && (
        <TimelineSlider
          progress={progress}
          puntos={puntos}
          start={start}
          end={end}
          current={current}
          playing={playing}
          onPlay={togglePlay}
          onScrub={scrub}
          onPick={(id) => pick(id)}
        />
      )}

      <MilestoneModal punto={selected} onClose={() => setSelectedId(null)} />
    </div>
  );
}
